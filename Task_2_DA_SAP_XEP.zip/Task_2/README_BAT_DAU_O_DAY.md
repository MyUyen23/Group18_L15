# TASK 2 — Cách dùng thư mục này

**Chọn 1 trong 2 nhánh:**

1. **Thành viên Task 3 / Task 4:** chỉ vào `00_DU_LIEU_CHUNG/` → đọc `README_CHO_CAC_TASK_KHAC.md` → tải riêng thư mục đó (hoặc ZIP riêng). **Không cần tải `01_NOI_BO_TASK_2`**.
2. **Người làm Task 2:** vào `01_NOI_BO_TASK_2/` → đọc `README_TASK2_NOI_BO.md` → chạy `run_task2.py` tại thư mục hiện tại khi cần tái lập kết quả.

**LaTeX / PDF hình / bảng trình bày:** không đóng gói ở đây. Giữ trong ZIP riêng `MT2013_MyUyen_PRISM_COMPILE_OK(2).zip` như yêu cầu. `01_NOI_BO_TASK_2/tables` là **bảng CSV kiểm toán/số liệu gốc**, không phải bảng LaTeX trình bày.

Không di chuyển riêng `01_NOI_BO_TASK_2` ra khỏi `Task_2` rồi chạy, vì code sử dụng đường dẫn tương đối để ghi dữ liệu sang `00_DU_LIEU_CHUNG`.

Các số liệu nghiên cứu không sửa đổi. Đã đổi duy nhất đường dẫn ghi và đọc dữ liệu sau xử lý giữa các thư mục, đồng thời tạo file khởi chạy tiện dụng.
