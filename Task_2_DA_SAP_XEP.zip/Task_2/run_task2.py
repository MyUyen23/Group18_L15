"""Run NSL-KDD Task 2 reproducible data preparation (not the LaTeX report)."""
from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parent
script = root / "01_NOI_BO_TASK_2" / "preprocessing.py"
subprocess.run([sys.executable, str(script)], cwd=root, check=True)
