"""Additional audits and auditable data sources for Chapter 2; no fitted transforms."""
from pathlib import Path
import json,re,io
import pandas as pd
import numpy as np
from matplotlib.cbook import boxplot_stats
from preprocessing import ROOT as P, SHARED, PROCESSED, FEATURES, CATS, RATES, BINARY, COMPARE, save
UCI='https://kdd.ics.uci.edu/databases/kddcup99/task.html'
SCHEMA='https://kdd.ics.uci.edu/databases/kddcup99/kddcup.names'
UNB='https://www.unb.ca/cic/datasets/nsl.html'
DEFINITIONS={
 'rows':'Số bản ghi dữ liệu; không tính tiêu đề', 'fields':'Số trường trong mỗi bản ghi TXT gốc',
 'missing_cells':'Số ô NA sau khi đọc TXT', 'blank_string_cells':'Số ô chuỗi rỗng sau strip trên dữ liệu đọc nguyên dạng chuỗi',
 'nonfinite_cells':'Số ô +inf/-inf trong 38 đặc trưng số và difficulty; NA đếm riêng',
 'type_errors':'Số ô không thiếu nhưng chuyển sang số thất bại trong 38 đặc trưng số và difficulty',
 'duplicate43_extra':'Số dòng dư khi giữ một dòng cho mỗi tổ hợp đủ 43 trường',
 'duplicate41_extra':'Số dòng dư khi giữ một dòng cho mỗi tổ hợp 41 đặc trưng',
 'duplicate41_groups':'Số tổ hợp 41 đặc trưng xuất hiện ít nhất hai lần',
 'duplicate41_involved':'Tổng số dòng thuộc các tổ hợp 41 đặc trưng xuất hiện ít nhất hai lần',
 'conflict_groups':'Số tổ hợp 41 đặc trưng có ít nhất hai attack_name khác nhau',
 'conflict_rows':'Tổng số dòng thuộc tổ hợp xung đột attack_name',
 'binary_conflict_groups':'Số tổ hợp 41 đặc trưng có cả Normal và Attack',
 'binary_conflict_rows':'Tổng số dòng thuộc tổ hợp xung đột Normal/Attack',
 'negative_cells':'Số ô âm trong 38 đặc trưng số',
 'rate_outside_cells':'Số ô ngoài [0,1] trong 15 đặc trưng tỷ lệ',
 'binary5_invalid_cells':'Số ô ngoài {0,1} ở land/logged_in/root_shell/is_host_login/is_guest_login',
 'su_not_binary_rows':'Số dòng su_attempted ngoài {0,1}; kiểm tra riêng tất cả bằng 2',
 'constant_features':'Số đặc trưng trong 41 biến chỉ có một giá trị',
 'near_constant_features':'Số đặc trưng có tần suất mốt >=99%, loại biến hằng',
 'domain_invalid_excluding_su':'Tổng vi phạm âm + ngoài miền tỷ lệ + ngoài miền 5 chỉ báo; có thể đếm một ô nhiều lần; không gồm su_attempted'
}
def enrich():
    audits=json.loads((P/'tables/audit.json').read_text());inv=[];labels=[];cats=[];dfs={}
    for split,stem in [('train','KDDTrain+'),('test','KDDTest+')]:
        d=pd.read_csv(PROCESSED/f'{split}_clean.csv');dfs[split]=d
        gr=d.groupby(FEATURES,observed=True).label_binary.agg(['size','nunique'])
        bad=gr[gr['nunique']>1]
        audits[split]['binary_conflict_groups']=len(bad)
        audits[split]['binary_conflict_rows']=int(bad['size'].sum())
        d.merge(bad.reset_index()[FEATURES],on=FEATURES).to_csv(P/f'tables/{split}_binary_conflicting_rows.csv',index=False)
        arff=(P/f'data/raw/{stem}.arff').read_text()
        attrs=re.findall(r"@attribute '([^']+)'",arff)
        assert attrs[:41]==FEATURES and len(attrs)==42
        body=re.split(r'@data\s*',arff,flags=re.I)[1]
        a=pd.read_csv(io.StringIO(body),header=None,names=FEATURES+['class'],quotechar="'")
        assert a.shape==(len(d),42)
        assert np.array_equal(a[FEATURES].to_numpy(),d[FEATURES].to_numpy()), 'ARFF feature mismatch: '+split
        assert np.array_equal(a['class'].map({'normal':0,'anomaly':1}),d.label_binary), 'ARFF label mismatch'
        for ext,fields in [('txt',43),('arff',42)]:
            inv.append(dict(split=split,file=f'{stem}.{ext}',rows=len(d),fields=fields,features=41,label='attack_name' if ext=='txt' else 'class: normal/anomaly',difficulty=ext=='txt',role='mô tả và phát triển mô hình' if split=='train' else 'đánh giá dự đoán độc lập',arff_features_and_binary_match_txt=True))
        for level,col in [('five_groups','attack_category'),('binary','label_binary')]:
            for label,n in d[col].value_counts(sort=False).items():
                labels.append(dict(split=split,level=level,label=label,count=n,percent=100*n/len(d)))
        for c in CATS:
            for v,n in d[c].value_counts().items():cats.append(dict(split=split,feature=c,value=v,count=n,percent=100*n/len(d)))
    before=pd.read_csv(P/'tables/before_after.csv')
    before['five_group_total_after']=[len(dfs[x]) for x in before.split]
    before['binary_total_after']=[len(dfs[x]) for x in before.split]
    before['unmapped_after']=0
    save(before,'before_after.csv')
    save(pd.DataFrame(inv),'dataset_inventory.csv');save(pd.DataFrame(labels),'label_distribution.csv');save(pd.DataFrame(cats),'categorical_distribution.csv')
    q=pd.DataFrame(audits).rename_axis('criterion').reset_index();q['definition_vi']=q.criterion.map(DEFINITIONS)
    assert q.definition_vi.notna().all();save(q,'quality_audit.csv')
    (P/'tables/audit.json').write_text(json.dumps(audits,ensure_ascii=False,indent=2))
    old=pd.read_csv(PROCESSED/'data_dictionary.csv')
    old[~old.name.isin(FEATURES)].to_csv(PROCESSED/'metadata_dictionary.csv',index=False)
    dd=[]
    for i,c in enumerate(FEATURES,1):
        row=old[old.name==c].iloc[0];group='basic' if i<=9 else 'content' if i<=22 else 'time_traffic' if i<=31 else 'host_traffic'
        kind='định tính danh nghĩa' if c in CATS else 'tỷ lệ bị chặn' if c in RATES else 'chỉ báo nhị phân theo định nghĩa' if c in BINARY+['su_attempted'] else 'định lượng rời rạc / số nguyên ghi nhận'
        note='Không âm; cận trên lý thuyết chưa xác định từ nguồn'
        unit='số đếm'
        if c in CATS:note='Danh mục hợp lệ theo schema ARFF';unit='nhãn danh mục, không có đơn vị'
        elif c in RATES:note='[0,1]; tỷ lệ không phải phần trăm 0–100';unit='tỷ lệ không đơn vị'
        elif c in BINARY+['su_attempted']:note='{0,1} theo mô tả; kiểm toán thực tế tách riêng';unit='chỉ báo 0/1'
        elif c=='duration':unit='giây (số nguyên được lưu)'
        elif c in ['src_bytes','dst_bytes']:unit='byte'
        elif c in ['count','srv_count','dst_host_count','dst_host_srv_count']:unit='kết nối'
        meaning=row.description;status='Định nghĩa theo bảng KDD; tên/thứ tự theo schema và ARFF'
        if c=='su_attempted':meaning='Chỉ báo thử lệnh su root theo mô tả gốc';note+='; giá trị 2 là bất nhất được giữ nguyên, xem 2.5'
        if c=='is_host_login':
            meaning='Chỉ báo có tên is_host_login trong schema; ý nghĩa chi tiết chưa xác định từ nguồn'
            note='{0,1} là miền kiểm tra theo bản ghi; không tự đồng nhất với is_hot_login của bảng mô tả cũ'
            status='Tên xác minh; ngữ nghĩa chưa giải quyết'
        if i>=32:
            note+='; kích thước cửa sổ và công thức triển khai NSL-KDD chưa xác định từ nguồn schema'
            status='Tên theo schema; diễn giải nhóm host từ KDD, công thức từng trường chưa xác minh đầy đủ'
        if c=='dst_host_srv_diff_host_rate':
            meaning='Tỷ lệ về khác biệt host trong lịch sử kết nối cùng dịch vụ; mẫu số và hướng host chưa xác định từ nguồn'
        use='tần số và bảng chéo' if c in CATS else 'mô tả số và kiểm toán miền; ứng viên predictor'
        if c in BINARY+['su_attempted']:use='tần số chỉ báo và kiểm toán miền; ứng viên predictor'
        if c in ['hot','num_compromised']:note+='; tiêu chí nhận diện hot/compromised chi tiết chưa có trong bảng nguồn'
        dd.append(dict(feature_name=c,position=i,group=group,variable_type=kind,meaning_vi=meaning,unit_or_scale=unit,expected_domain_or_note=note,used_for=use,source_url=UCI+' ; '+SCHEMA,definition_status=status))
    pd.DataFrame(dd).to_csv(PROCESSED/'data_dictionary.csv',index=False)
    s=pd.read_csv(P/'tables/selected_descriptive.csv');save(s,'descriptive_statistics.csv')
    m=pd.read_csv(P/'tables/attack_mapping.csv');m['source_url']=np.where(m.source.eq('UCI training_attack_types'),'https://kdd.ics.uci.edu/databases/kddcup99/training_attack_types',np.where(m.attack_name.eq('normal'),UNB,'https://www.mdpi.com/1424-8220/22/5/2018'))
    m['note']=m.attack_name.map({'worm':'Quy ước DoS theo Bảng 3 Imrana; một số nguồn xếp R2L','httptunnel':'Quy ước R2L theo Bảng 3 Imrana; một số nguồn xếp U2R'}).fillna('Giữ chính tả nhãn TXT; không sao chép số tổng từ bài báo')
    save(m,'attack_mapping.csv')
    m.to_csv(SHARED/'attack_mapping.csv', index=False, float_format='%.15g')
    hist=[];box=[];fliers=[];train=dfs['train']
    for c in COMPARE:
        arr=[train.loc[train.label_binary.eq(v),c].to_numpy() for v in [0,1]]
        if c=='src_bytes':arr=[np.log1p(a) for a in arr]
        edges=np.linspace(0,max(a.max() for a in arr),41)
        for g,a in zip(['Normal','Attack'],arr):
            counts,_=np.histogram(a,bins=edges)
            for j,n in enumerate(counts):hist.append(dict(feature=c,group=g,scale='log1p' if c=='src_bytes' else 'original',bin=j,left=edges[j],right=edges[j+1],right_inclusive=j==39,count=n,percent=100*n/len(a),group_n=len(a)))
            st=boxplot_stats(a,whis=1.5)[0]
            box.append(dict(feature=c,group=g,scale='log1p' if c=='src_bytes' else 'original',n=len(a),q1=st['q1'],median=st['med'],q3=st['q3'],whisker_low=st['whislo'],whisker_high=st['whishi'],outlier_n=len(st['fliers'])))
            for v,n in zip(*np.unique(st['fliers'],return_counts=True)):fliers.append(dict(feature=c,group=g,value=v,count=n))
    save(pd.DataFrame(hist),'histogram_bins.csv');save(pd.DataFrame(box),'boxplot_statistics.csv');save(pd.DataFrame(fliers),'boxplot_fliers.csv')
    save(pd.read_csv(P/'tables/train_attack_category_distribution.csv'),'bar_chart_data.csv')
    print('FULL SCOPE:',{s:{k:v for k,v in a.items() if 'binary_conflict' in k} for s,a in audits.items()})
    print('ARFF/TXT: all features and binary labels identical, both splits')
    print('Labels:',{s:d.attack_name.nunique() for s,d in dfs.items()},'test-only:',sorted(set(dfs['test'].attack_name)-set(train.attack_name)))
