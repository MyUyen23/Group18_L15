# NỘI BỘ TASK 2 — Không cần tải khi làm Task khác

Đây là nơi giữ **dữ liệu raw, code, các bảng CSV/JSON giải thích riêng phần 2.5–2.7 và 4.1–4.2**. Người làm Task khác chỉ cần `../00_DU_LIEU_CHUNG`.

## Cây dữ liệu
- `data/raw/`: TXT/ARFF gốc, giữ nguyên để tái lập.
- `preprocessing.py`: kiểm tra raw, ánh xạ nhãn, tính số liệu mô tả, so sánh nhóm, xuất kết quả.
- `full_scope_data.py`: đối chiếu ARFF/TXT, từ điển, bảng chéo/histogram/boxplot và nguồn nhãn.
- `tables/`: bằng chứng thống kê CSV/JSON (chỉ Task 2 hoặc giảng viên kiểm toán cần); **không** phải input mặc định cho các Task khác.
- `figures/`: có thể được Python tạo ra khi chạy; **không lưu hình ở gói này** vì hình chính thức đã để ở ZIP PRISM riêng.
- `requirements.txt`: phiên bản thư viện cho việc tái lập.

## Chạy lại trên Windows bằng PowerShell
Mở VS Code ở thư mục `Task_2` rồi chạy:
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r 01_NOI_BO_TASK_2/requirements.txt
.\.venv\Scripts\python.exe run_task2.py
```
Lệnh cuối chạy `preprocessing.py` và tự gọi `full_scope_data.py`. Nó sẽ cập nhật bảng nội bộ ở `tables/`, ghi lại 4 CSV chung trong `../00_DU_LIEU_CHUNG/data/processed/` và `../00_DU_LIEU_CHUNG/attack_mapping.csv`. Hình PDF có thể phát sinh ở `figures/` **chỉ để kiểm chứng**, không cần gửi thêm trong Task 2.

**KHÔNG** chạy `build_report.py`, `build_introduction.py` hoặc trình biên dịch LaTeX cũ. LaTeX, bảng trình bày, hình báo cáo phải nằm trong ZIP `MT2013_MyUyen_PRISM_COMPILE_OK(2).zip` độc lập.

## Đầu ra nội bộ dùng cho báo cáo
- 2.5: `quality_audit.csv`, `schema_audit.csv`, `all_numeric_descriptive.csv`, `audit.json`, `*_conflicting_rows.csv`.
- 2.6: `before_after.csv`, `attack_mapping.csv` (bản chính được đưa sang thư mục dùng chung).
- 2.7: Quy ước ở `../00_DU_LIEU_CHUNG/QUY_UOC_DU_LIEU.md`.
- 4.1: `descriptive_statistics.csv`, `selected_descriptive.csv`, `categorical_distribution.csv`.
- 4.2: `label_distribution.csv`, `normal_attack_comparison.csv`, `histogram_bins.csv`, `boxplot_statistics.csv`, `boxplot_fliers.csv`, `bar_chart_data.csv` và các file nhãn từng tập.

Các tên file đầu ra và nội dung thống kê tính toán giữ nguyên; chỉ thay đổi **đường dẫn lưu `data/processed`** sang phần dùng chung.
